# Real-Time Data Pipeline for Stock Market Analysis — Presentation Demo

This presentation version keeps the project's data-engineering flow but removes paid/cloud dependencies.

## Demo architecture

Sample stock generator
→ local JSONL stream
→ consumer/processor
→ CSV data store
→ Streamlit dashboard

The original project used Alpha Vantage + Confluent Cloud Kafka + Aiven PostgreSQL.
This demo version uses local sample data so it can run without API keys, Kafka Cloud,
PostgreSQL, or internet access.

## Run in VS Code

### 1. Install packages

```powershell
pip install -r requirements.txt
```

### 2. Terminal 1 — Producer

```powershell
python producer.py
```

This generates a new stock record every 2 seconds in `data/stock_stream.jsonl`.

### 3. Terminal 2 — Consumer

```powershell
python consumer.py
```

This reads new records, calculates price change/status, and stores them in
`data/processed_stock_data.csv`.

### 4. Terminal 3 — Streamlit dashboard

```powershell
streamlit run dashboard.py
```

The dashboard opens in the browser.

## Presentation explanation

- Producer: generates simulated stock-market events with OHLC and volume.
- Stream: JSONL file represents the event stream for this offline demo.
- Consumer: reads, processes, transforms, and stores each event.
- Dashboard: Streamlit reads the processed data and displays KPIs, trends, volume,
  latest snapshot, and recent records.

For a production deployment, the local stream can be replaced by Kafka and the CSV
store can be replaced by PostgreSQL without changing the dashboard concept.
