import json
import random
import time
from pathlib import Path
from datetime import datetime
import pandas as pd

DATA = Path("data")
DATA.mkdir(exist_ok=True)

STREAM = DATA / "stock_stream.jsonl"
OUTPUT = DATA / "processed_stock_data.csv"
REJECTED = DATA / "rejected_records.csv"

stocks = {
    "AAPL": 228.50,
    "GOOG": 241.20,
    "MSFT": 511.00,
    "AMZN": 228.00,
    "TSLA": 430.00
}

position = 0

print("Stock Data Pipeline Started")

while True:

    # =========================
    # 1. INGESTION
    # =========================

    symbol = random.choice(list(stocks))
    previous = stocks[symbol]

    open_price = round(previous, 2)
    close_price = round(previous + random.uniform(-2, 2), 2)
    high_price = round(max(open_price, close_price) + random.uniform(0, 1.5), 2)
    low_price = round(min(open_price, close_price) - random.uniform(0, 1.5), 2)
    volume = random.randint(10000, 100000)

    record = {
        "symbol": symbol,
        "timestamp": datetime.now().isoformat(),
        "open": open_price,
        "high": high_price,
        "low": low_price,
        "close": close_price,
        "volume": volume
    }

    # Raw data → Landing zone
    with open(STREAM, "a") as f:
        f.write(json.dumps(record) + "\n")

    print("\nINGESTED:", record)


    # =========================
    # 2. LOAD RAW DATA
    # =========================

    with open(STREAM, "r") as f:
        f.seek(position)
        lines = f.readlines()
        position = f.tell()


    # =========================
    # 3. CLEAN + VALIDATE
    # =========================

    for line in lines:

        data = json.loads(line)
        errors = []

        # Null check
        for field in [
            "symbol", "timestamp", "open",
            "high", "low", "close", "volume"
        ]:
            if data.get(field) is None:
                errors.append(field + " is NULL")

        # Numeric validation
        for field in [
            "open", "high", "low",
            "close", "volume"
        ]:
            if not isinstance(data.get(field), (int, float)):
                errors.append(field + " is not numeric")

       
        # OHLC validation
        if (
            isinstance(data.get("low"), (int, float))
            and isinstance(data.get("high"), (int, float))
        ):
            if data["low"] > data["high"]:
                errors.append("Low cannot be greater than High")

        if (
            isinstance(data.get("low"), (int, float))
            and isinstance(data.get("open"), (int, float))
            and isinstance(data.get("high"), (int, float))
        ):
            if not data["low"] <= data["open"] <= data["high"]:
                errors.append("Invalid Open price")

        if (
            isinstance(data.get("low"), (int, float))
            and isinstance(data.get("close"), (int, float))
            and isinstance(data.get("high"), (int, float))
        ):
            if not data["low"] <= data["close"] <= data["high"]:
                errors.append("Invalid Close price")

        # =========================
        # 4. REJECT INVALID DATA
        # =========================

        if errors:

            print("❌ REJECTED:", errors)

            pd.DataFrame([{
                "symbol": data.get("symbol"),
                "reason": ", ".join(errors)
            }]).to_csv(
                REJECTED,
                mode="a",
                header=not REJECTED.exists(),
                index=False
            )

            continue


        # =========================
        # 5. TRANSFORMATION
        # =========================

        data["symbol"] = data["symbol"].strip().upper()

        data["change"] = round(
            data["close"] - data["open"], 2
        )

        data["status"] = (
            "UP" if data["change"] > 0
            else "DOWN" if data["change"] < 0
            else "UNCHANGED"
        )


        # =========================
        # 6. STORAGE
        # =========================

        pd.DataFrame([data]).to_csv(
            OUTPUT,
            mode="a",
            header=not OUTPUT.exists(),
            index=False
        )

        print(
            f"✅ ACCEPTED | {data['symbol']} | "
            f"Change: {data['change']} | "
            f"Status: {data['status']}"
        )

    time.sleep(2)