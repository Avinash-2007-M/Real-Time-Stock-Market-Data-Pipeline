import pandas as pd
import streamlit as st
from pathlib import Path

DATA = Path("data")
FILE = DATA / "processed_stock_data.csv"
REJECTED = DATA / "rejected_records.csv"

st.set_page_config(
    page_title="Stock Data Pipeline",
    layout="wide"
)

st.title("📊 Real-Time Stock Data Pipeline")

if not FILE.exists():
    st.warning("Waiting for processed data...")
    st.stop()

df = pd.read_csv(FILE)

df["timestamp"] = pd.to_datetime(
    df["timestamp"],
    format="mixed",
    errors="coerce",
    utc=True
)

# =========================
# KPI
# =========================

accepted = len(df)

if REJECTED.exists():
    rejected = len(pd.read_csv(REJECTED))
else:
    rejected = 0

total = accepted + rejected

c1, c2, c3 = st.columns(3)

c1.metric("Total Records", total)
c2.metric("Accepted", accepted)
c3.metric("Rejected", rejected)

st.divider()


# =========================
# CLEANED DATA
# =========================

st.subheader("✅ Cleaned Stock Data")

st.dataframe(
    df.tail(20),
    use_container_width=True,
    hide_index=True
)


# =========================
# CLOSING PRICE
# =========================

st.subheader("📈 Closing Price")

chart = df.pivot_table(
    index="timestamp",
    columns="symbol",
    values="close",
    aggfunc="last"
)

st.line_chart(chart)


# =========================
# REJECTED DATA
# =========================

st.subheader("❌ Rejected Records")

if rejected:

    rejected_df = pd.read_csv(REJECTED)

    st.dataframe(
        rejected_df,
        use_container_width=True,
        hide_index=True
    )

else:

    st.success("No rejected records.")